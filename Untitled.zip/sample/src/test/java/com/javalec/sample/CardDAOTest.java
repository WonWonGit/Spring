package com.javalec.sample;

import java.util.List;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.javalec.web.sample.dao.CardDAO;
import com.javalec.web.sample.model.CardVO;

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = {

		"classpath:spring/root-context.xml",

		"classpath:spring/dataSource-context.xml"

		})

public class CardDAOTest {

	private static final Logger logger = LoggerFactory.getLogger(CardDAOTest.class);

	@Inject
	private CardDAO CardDAO;
	

	@Test 
	public void gdtCardTest() throws Exception {

		List<CardVO> cardList = CardDAO.getCard();
		logger.info("\n Card List \n ");
		if(cardList.size() > 0) {
			for(CardVO list : cardList) {
				logger.info(list.mean);
			}
		} else {
			logger.info("데이터가 없습니다.");
		}

	}
	@Test @Ignore
	public void gdtCardUserTest() throws Exception {

		List<CardVO> cardList = CardDAO.getCardUser("aaa");
		logger.info("\n Card List Users \n ");
		if(cardList.size() > 0) {
			for(CardVO list : cardList) {
				logger.info(list.word);
				logger.info(list.mean);
				logger.info(list.important);
			}
		} else {
			logger.info("데이터가 없습니다.");
		}

	}
	
	@Test @Ignore
	public void InsertCardTest() throws Exception {
		
		CardVO cardVO = new CardVO();
		
		cardVO.setWord("apple");
		cardVO.setMean("사과");
		cardVO.setImportant("Y");
		cardVO.setUser("aaa");

		int result = CardDAO.insertCard(cardVO);
		logger.info("\n Insert Card Result " +result);

		if(result == 1) {
			logger.info("\n 등록 성공 ");
		} else {
			logger.info("\n 등록 실패");
		}

	}
	
	@Test @Ignore
	public void testUpdateBoard() throws Exception {

		CardVO cardVO = new CardVO();

		cardVO.setCard_num(4);
		cardVO.setWord("banana");
		cardVO.setMean("바나나");
		cardVO.setImportant("N");

		int result = CardDAO.updateCard(cardVO);
				
		logger.info("\n Update Board Result \n ");

		if(result > 0) {
			logger.info("\n 게시물 수정 성공 ");
		} else {
			logger.info("\n 게시물 수정 실패");
		}
	}
	
	@Test  @Ignore
	public void tesDeleteCard() throws Exception {

		int result = CardDAO.deleteCard(6);

		logger.info("\n Delete Card Result \n ");
		if(result > 0) {
			logger.info("\n 게시물 삭제 성공 ");
		} else {
			logger.info("\n 게시물 삭제 실패");
		}
	}


	
}	

