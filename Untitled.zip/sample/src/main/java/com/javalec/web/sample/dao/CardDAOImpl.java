package com.javalec.web.sample.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.javalec.web.sample.model.CardVO;

@Repository
public class CardDAOImpl implements CardDAO{

	@Inject
	private SqlSession sqlSession;

	@Override
	public List<CardVO> getCard() throws Exception {
		
		return sqlSession.selectList("com.javalec.web.sample.cardMapper.getCard");
	}

	@Override
	public List<CardVO> getCardUser(String user) throws Exception {
		
		return sqlSession.selectList("com.javalec.web.sample.cardMapper.getCardUser",user);
	}

	@Override
	public int insertCard(CardVO cardVO) throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.insert("com.javalec.web.sample.cardMapper.insertCard",cardVO);
	}

	@Override
	public int updateCard(CardVO cardVO) throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.update("com.javalec.web.sample.cardMapper.updateCard",cardVO);
	}

	@Override
	public int deleteCard(int card_num) throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.delete("com.javalec.web.sample.cardMapper.deleteCard",card_num);
	}

}
