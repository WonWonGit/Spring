package com.javalec.web.sample.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.javalec.web.sample.service.CardService;

@Controller
@RequestMapping(value="/card")
public class CardController {

	@Inject
	private CardService cardService;
	
	@RequestMapping(value="/card",method=RequestMethod.GET)
	public String getCard(Model model) throws Exception {
		model.addAttribute("cardList",cardService.getCard());
		
		return "card/index";
	}
	
}
