package com.javalec.web.sample.dao;

import java.util.List;

import com.javalec.web.sample.model.CardVO;

public interface CardDAO {
	public List<CardVO> getCard() throws Exception;
	public List<CardVO> getCardUser(String user) throws Exception;
	public int insertCard(CardVO cardVO) throws Exception;
	public int updateCard(CardVO cardVO) throws Exception;
	public int deleteCard(int card_num) throws Exception;

}
