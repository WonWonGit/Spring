package com.javalec.web.sample.service;

import java.util.List;

import com.javalec.web.sample.model.CardVO;

public interface CardService {
	public List<CardVO> getCard() throws Exception;
}
