package com.javalec.web.sample.model;


public class CardVO {

	public int card_num;
	public String word;
	public String mean;
	public String important;
	public String user;
	
	public int getCard_num() {
		return card_num;
	}
	public void setCard_num(int card_num) {
		this.card_num = card_num;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getMean() {
		return mean;
	}
	public void setMean(String mean) {
		this.mean = mean;
	}
	public String getImportant() {
		return important;
	}
	public void setImportant(String important) {
		this.important = important;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		return "CardVO [card_num=" + card_num + ", word=" + word + ", mean=" + mean + ", important=" + important
				+ ", user=" + user + "]";
	}
	
	
	
}
