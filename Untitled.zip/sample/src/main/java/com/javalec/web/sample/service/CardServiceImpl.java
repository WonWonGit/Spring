package com.javalec.web.sample.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.javalec.web.sample.dao.CardDAO;
import com.javalec.web.sample.model.CardVO;

@Service
public class CardServiceImpl implements CardService{
	
	@Inject
	private CardDAO cardDAO;

	@Override
	public List<CardVO> getCard() throws Exception {

		return cardDAO.getCard();
	}

}
